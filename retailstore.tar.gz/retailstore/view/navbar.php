<br />
<br />
<br />
<footer>
    <div class="navbar navbar-inverse navbar-fixed-bottom">
        <div class="container">
            <div class="navbar-collapse collapse" id="footer-body">
                <ul class="nav navbar-nav">
                    <li id='categories'><a href="categories.php">Categories</a></li>
				    <li id='products'><a href="products.php">Products</a></li>
				    <li id='sales'><a href="sales.php">Sales</a></li>
				    <li id='customers'><a href="customers.php">Customers</a></li>
				    <li id='coupons'><a href="coupons.php">Gift Coupons</a></li>
				    <li id='settings'><a href="settings.php">Settings</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<style type="text/css">
.navbar-default .navbar-nav>.active>a, .navbar-default .navbar-nav>.active>a:hover, .navbar-default .navbar-nav>.active>a:focus 
{
	color: #f5f5f5;
    background-color: #333333;
}
</style>